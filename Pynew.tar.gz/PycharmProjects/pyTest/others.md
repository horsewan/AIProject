ssh远程下载文件

scp -i /Users/linda/stun.pem 47.75.121.191:/etc/turnserver/turn_server_pkey.pem /Users/linda/Downloads/

ssh远程上传文件

scp -i /Users/linda/stun.pem /Users/linda/Downloads/turn_server_pkey.pem  47.75.121.191:/etc/turnserver

ssh远程上传文件夹

scp -i /Users/linda/stun.pem -r /Users/linda/Downloads/  47.75.121.191:/UserDir

scp -i /Users/linda/eth2.pem  /Users/linda/Work/PycharmProjects/facenet/faceserver/ai/views.py  47.52.117.248:/mnt/virtual/faceserver/ai

断点续传 --上传

rsync -avzP -e 'ssh -i eth1.pem' --bwlimit=5000 chaindata.tar 47.75.113.31:/mnt/ethData/  >> send.log &

rsync -avP -e 'ssh -i eth1.pem' --bwlimit=4000 chaindata.tar 47.75.113.31:/mnt/ethData/

rsync -avP -e 'ssh ' --bwlimit=30000  root@192.168.124.186:/home/ethData/ethData.tar ./

temp
rsync -avP -e 'ssh  -i /Users/linda/eth1.pem' --bwlimit=3000  ./ethData.tar 47.75.113.31:/mnt/ethData.tar


rsync -avPr -e 'ssh -i eth1.pem' --bwlimit=4000  47.75.113.31:/mnt/ethData/

远程服务器登陆

ssh 47.75.113.31  -i /Users/linda/eth1.pem

ssh 47.75.121.191 -i /Users/linda/stun.pem

ssh 47.75.111.229 -i /Users/linda/stun2.pem

ssh 47.52.117.248 -i /Users/linda/eth2.pem

ssh 47.75.135.192 -i /Users/linda/priveth.pem

工作日志填写地方：

https://gitee.com/ruitao/dashboard/wikis

centos自动启动脚本




https://www.jianshu.com/p/8a5d968afc7f


centos 安装git2.0

1,yum install epel-release

2,yum install https://centos7.iuscommunity.org/ius-release.rpm

3,yum install git2u

go 语言安装

1，wget https://dl.google.com/go/go1.10.3.linux-amd64.tar.gz

2，解压安装 设置PATH，GOPATH

网络配置

iptables -t nat -I PREROUTING -d 47.75.111.229 -p tcp --dport 8080 -j DNAT --to 172.31.1.10:8080

pyenv activate env365   python虚拟机打开在 192.168.124.186



python   虚拟环境

pyenv activate virtual   --  ssh 47.52.117.248 -i /Users/linda/eth2.pem


0xc57d591db46d01d8fb53169af11c3a265f4f470f


0xff86d8f44f3f317f85226c38ff29a19737ef4652



nodejs nvm 安装

https://github.com/creationix/nvm#install-script