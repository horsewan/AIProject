1,安装secp256k1-

yum install libtool

git clone https://github.com/cryptonomex/secp256k1-zkp.git
cd secp256k1-zkp
./autogen.sh && ./configure
make
sudo make install

2, 首先安装python3.6.5的虚拟环境
然后再做以下动作
pip3 install --upgrade pip setuptools
pip3 install simplejson

pip3 install populus
pip3 install gevent
