启动roomsever

 dev_appserver.py --host=192.168.124.186 --admin_host=192.168.124.186 --api_host=192.168.124.186 ./apprtc/out/app_engine 服务器

 nohup dev_appserver.py --host 192.168.124.186 --admin_host 192.168.124.186 --api_host 192.168.124.186 --api_port 5678 ./apprtc/out/app_engine  >> output.log 2>&1 &

启动信令服务器

$GOPATH/bin/collidermain -port=8089 -tls=false

nohup ./collide/bin/collidermain -port=8089 -tls=false >> sign.log 2>&1 &

启动turn/stun/ice 服务器

turnserver -o -a


dev_appserver.py --host 0.0.0.0