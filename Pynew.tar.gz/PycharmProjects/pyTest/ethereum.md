以太坊公链快速账本运行命令

geth --fast --cache=4096 --datadir /home/data/.ethereum/ --ethash.dagdir /home/data/.ethash --rpc --rpcaddr 172.31.1.6 --rpcport 8045 --rpcapi personal,web3,eth,net --ws --wsaddr 172.31.1.6 —-wsport 8046 —-wsorigins *
nohup geth --fast --cache=4096 --datadir /home/data/.ethereum/ --ethash.dagdir /home/data/.ethash --rpc --rpcaddr 172.31.1.6 --rpcport 8045 --rpcapi personal,web3,eth,net --ws --wsaddr 172.31.1.6 —-wsport 8046 —-wsorigins * >> output.log 2>&1 &



以太坊公链全量账本运行命令
geth --syncmode full --cache=4096 -trie-cache-gens 1024 --datadir "/mnt/.ethereum" --rpc --rpcaddr 172.31.1.11  --rpcport 8545 —rpcapi personal,web3,eth,net
nohup geth --syncmode full --cache=4096 -trie-cache-gens 1024 --datadir "/mnt/.ethereum" --rpc --rpcaddr 172.31.1.11  --rpcport 8545 —rpcapi personal,web3,eth,net  >> output.log 2>&1 &

geth --syncmode full --cache=2048 -trie-cache-gens 1024 --datadir "/mnt/ethData/.ethereum" --rpc --rpcaddr 172.31.1.11  --rpcport 8545 —rpcapi personal,web3,eth,net
nohup geth --syncmode full --cache=2048 -trie-cache-gens 1024 --datadir "/mnt/ethData/.ethereum" --rpc --rpcaddr 172.31.1.11  --rpcport 8545 —rpcapi personal,web3,eth,net >> output.log 2>&1 &

nohup geth --syncmode full --cache=4096 -trie-cache-gens 1024 --datadir "/home/ethData/.ethereum" --rpc --rpcaddr 192.168.1.138 --rpcport 8545 —rpcapi personal,web3,eth,net >> output.log 2>&1 &





nohup geth --fast --cache=4096 --datadir /home/data/.ethereum/ --ethash.dagdir /home/data/.ethash --rpc --rpcaddr 172.31.1.6 --rpcport 8045 --rpcapi personal,web3,eth,net --ws --wsaddr 172.31.1.6 —-wsport 8046 —-wsorigins * >> output.log 2>&1 &

nohup geth --fast --cache=4096 --datadir /home/data/.ethereum/ --ethash.dagdir /home/data/.ethash --rpc --rpcaddr 172.31.1.6 --rpcport 8045 --rpcapi personal,web3,eth,net  >> output.log 2>&1 &

nohup geth --syncmode full --cache=4096 -trie-cache-gens 1024 --datadir "/mnt/ethData/.ethereum" --rpc --rpcaddr 172.31.1.6  --rpcport 8045 --rpcapi personal,web3,eth,net >> output.log 2>&1 &

