import tensorflow as tf
import numpy as np
import cv2
import facenet_model
import os
import imageio

def load_model(model):