from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from scipy import misc
import tensorflow as tf
import numpy as np
import sys
import os
import copy
import argparse
import facenet_model
import detect_face

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

def load_and_align_data_bypath(image_paths, image_size, margin, gpu_memory_fraction):
    minsize = 20  # minimum size of face
    threshold = [0.6, 0.7, 0.7]  # three steps's threshold
    factor = 0.709  # scale factor

    print('Creating networks and loading parameters')
    print(image_paths)
    print(image_size)
    print(margin)
    print(gpu_memory_fraction)
    pfiles=os.listdir(image_paths)

    with tf.Graph().as_default():
        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=gpu_memory_fraction)
        sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, log_device_placement=False))
        with sess.as_default():
            pnet, rnet, onet = detect_face.create_mtcnn(sess, None)

    tmp_image_paths = copy.copy(pfiles)
    #print(tmp_image_paths )
    img_list = []
    for image in tmp_image_paths:
        image=image_paths+"/"+image
        print(image)
        img = misc.imread(os.path.expanduser(image), mode='RGB')
        img_size = np.asarray(img.shape)[0:2]
        bounding_boxes, _ = detect_face.detect_face(img, minsize, pnet, rnet, onet, threshold, factor)
        if len(bounding_boxes) < 1:
            image_paths.remove(image)
            print("can't detect face, remove ", image)
            continue
        det = np.squeeze(bounding_boxes[0, 0:4])
        bb = np.zeros(4, dtype=np.int32)
        bb[0] = np.maximum(det[0] - margin / 2, 0)
        bb[1] = np.maximum(det[1] - margin / 2, 0)
        bb[2] = np.minimum(det[2] + margin / 2, img_size[1])
        bb[3] = np.minimum(det[3] + margin / 2, img_size[0])
        cropped = img[bb[1]:bb[3], bb[0]:bb[2], :]
        aligned = misc.imresize(cropped, (image_size, image_size), interp='bilinear')
        prewhitened = facenet_model.prewhiten(aligned)
        img_list.append(prewhitened)
    images = np.stack(img_list)
    return images


def load_and_align_data_byimage(imagefile, image_size, margin, gpu_memory_fraction):
    minsize = 20  # minimum size of face
    threshold = [0.6, 0.7, 0.7]  # three steps's threshold
    factor = 0.709  # scale factor

    print('Creating networks and loading parameters')
    print(imagefile)
    print(image_size)
    print(margin)
    print(gpu_memory_fraction)
    #pfiles=os.listdir(image_paths)

    with tf.Graph().as_default():
        gpu_options = tf.GPUOptions(per_process_gpu_memory_fraction=gpu_memory_fraction)
        sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options, log_device_placement=False))
        with sess.as_default():
            pnet, rnet, onet = detect_face.create_mtcnn(sess, None)

    #tmp_image_paths = copy.copy(pfiles)
    #print(tmp_image_paths )
    img_list = []
    image=copy.copy(imagefile)
    print (image)
    img = misc.imread(os.path.expanduser(image), mode='RGB')
    img_size = np.asarray(img.shape)[0:2]
    bounding_boxes, _ = detect_face.detect_face(img, minsize, pnet, rnet, onet, threshold, factor)
    det = np.squeeze(bounding_boxes[0, 0:4])
    bb = np.zeros(4, dtype=np.int32)
    bb[0] = np.maximum(det[0] - margin / 2, 0)
    bb[1] = np.maximum(det[1] - margin / 2, 0)
    bb[2] = np.minimum(det[2] + margin / 2, img_size[1])
    bb[3] = np.minimum(det[3] + margin / 2, img_size[0])
    cropped = img[bb[1]:bb[3], bb[0]:bb[2], :]
    aligned = misc.imresize(cropped, (image_size, image_size), interp='bilinear')
    prewhitened = facenet_model.prewhiten(aligned)
    img_list.append(prewhitened)
    images = np.stack(img_list)
    return images

def get_embs(model_path,image_path, image_size, margin, gpu_memory_fraction):
     images = load_and_align_data_bypath(image_path, image_size, margin, gpu_memory_fraction)
     with tf.Graph().as_default():
         with tf.Session() as sess:
             # Load the model
             facenet_model.load_model(model_path)
             # Get input and output tensors
             images_placeholder = tf.get_default_graph().get_tensor_by_name("input:0")
             embeddings = tf.get_default_graph().get_tensor_by_name("embeddings:0")
             phase_train_placeholder = tf.get_default_graph().get_tensor_by_name("phase_train:0")
             # Run forward pass to calculate embeddings
             feed_dict = {images_placeholder: images, phase_train_placeholder: False}
             emb = sess.run(embeddings, feed_dict=feed_dict)
     return emb

def get_emb(model_path,image_file, image_size, margin, gpu_memory_fraction):
     images = load_and_align_data_byimage(image_file, image_size, margin, gpu_memory_fraction)
     with tf.Graph().as_default():
         with tf.Session() as sess:
             # Load the model
             facenet_model.load_model(model_path)
             # Get input and output tensors
             images_placeholder = tf.get_default_graph().get_tensor_by_name("input:0")
             embeddings = tf.get_default_graph().get_tensor_by_name("embeddings:0")
             phase_train_placeholder = tf.get_default_graph().get_tensor_by_name("phase_train:0")
             # Run forward pass to calculate embeddings
             feed_dict = {images_placeholder: images, phase_train_placeholder: False}
             emb = sess.run(embeddings, feed_dict=feed_dict)
     return emb

model_path="../F195/20180408-102900.pb"
model_path2="../F192/20180402-114759.pb"
image_path="../Img"
image_file="../Img/zly_2.jpeg"
image_file2="../Img/xx_1.jpg"
image_size=160
margin=44
gpu_memory_fraction=1.0
image_files=os.listdir(image_path)
nrof_images = len(image_files)
print('Images:')
for i in range(nrof_images):
     print('%1d:%s' % (i, image_files[i]))
print('')
emb=get_embs(model_path,image_path, image_size, margin, gpu_memory_fraction)
emb2=get_embs(model_path2,image_path, image_size, margin, gpu_memory_fraction)
#emb=get_emb(model_path,image_file, image_size, margin, gpu_memory_fraction)
#emb2=get_emb(model_path,image_file2, image_size, margin, gpu_memory_fraction)
dist = np.sqrt(np.sum(np.square(np.subtract(emb[0, :], emb2[0, :]))))
print('  %1.4f  ' % dist, end='')
#print('Distance matrix')
#print('    ', end='')
#for i in range(nrof_images):
#    print('    %1d     ' % i, end='')
#print('')

for i in range(nrof_images):
    for j in range(nrof_images):
        dist = np.sqrt(np.sum(np.square(np.subtract(emb[i, :], emb[j, :]))))
        dist2 = np.sqrt(np.sum(np.square(np.subtract(emb2[i, :], emb2[j, :]))))
        print('%1d:%s vs %1d:%s  [1]%1.4f : [2]%1.4f' % (i,image_files[i],j,image_files[j],dist, dist2),end='')
        print('\n')