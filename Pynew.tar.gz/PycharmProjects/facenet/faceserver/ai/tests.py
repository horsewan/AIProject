# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase

import numpy as np
from math import log

#base=2.71

def fn(sr):
    tm=2.71-(sr+0.12)**6
    if (tm<=0.01) :
        tm=0.01
    ln=log(tm)
    if (ln<=0) :
        ln=0
    return ln

print(fn(1.2))

# Create your tests here.

