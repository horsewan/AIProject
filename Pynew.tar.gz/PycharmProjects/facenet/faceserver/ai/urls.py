from django.urls import path
from django.conf.urls import url
from .views import *

urlpatterns = [
    url(r'^upload/$', FileView.as_view(), name='file-upload'),
    url(r'^reg/$', RegView.as_view(), name='face-register'),
    url(r'^rec/$', RecView.as_view(), name='face_recognize'),
    url(r'^list/$', ListView.as_view(), name='face_v_list'),
    url(r'^ajax/$', django_image_and_file_upload_ajax, name='face_v_ajax'),
    #url(r'^upload/$', FileView.as_view(), name='file-upload'),
]

#urlpatterns = [
#    path('', views.index, name='index'),
#]
