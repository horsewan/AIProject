from rest_framework import serializers
from .models import *
class FileSerializer(serializers.ModelSerializer):
  class Meta():
    model = File
    fields = ('file', 'remark', 'timestamp')

class RegSerializer(serializers.ModelSerializer):  #注册序列化
  class Meta():
    model = Reg
    fields = ('file', 'regid', 'remark','timestamp')

class RecSerializer(serializers.ModelSerializer): #识别序列化
  class Meta():
    model = Rec
    fields = ('file', 'remark', 'timestamp')

class ListSerializer(serializers.ModelSerializer): #list
      class Meta():
        model = List
        fields = ('listid')

class ImageFileUploadForm(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = ('photo', 'regid', 'attachment',)