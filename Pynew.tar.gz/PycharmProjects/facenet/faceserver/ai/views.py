# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework import status
from faceserver.settings import *
from .serializers import *
#from .apps import AiConfig
import pickle
import numpy as np
from math import log

from .fd import facenet_distance

global  tf_grapth
tf_grapth= facenet_distance.init_tf()
global  embs
embs = facenet_distance.load_emb()


def fn_percent(sr):   ## change distancd to percentage
    tm=2.71-(sr+0.12)**6
    if (tm<=0.01) :
        tm=0.01
    ln=log(tm)
    if (ln<=0) :
        ln=0
    return ln


class FileView(APIView):
  parser_classes = (MultiPartParser, FormParser)
  def post(self, request, *args, **kwargs):
    file_serializer = FileSerializer(data=request.data)
    #print("#########")
    #print(file_serializer.is_valid())
    #print("aa")
    if file_serializer.is_valid():
      file_serializer.save()
      print(file_serializer.data['file'])
      return Response(file_serializer.data, status=status.HTTP_201_CREATED)
    else:
      return Response(file_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class RegView(APIView):
  parser_classes = (MultiPartParser, FormParser)
  def post(self, request, *args, **kwargs):
    file_serializer = RegSerializer(data=request.data)
    if file_serializer.is_valid():
      file_serializer.save()
      print("inputfile"+file_serializer.data['file']+"====inputkey="+file_serializer.data['regid'] )
      image_file="."+file_serializer.data['file']
      emb = facenet_distance.get_emb_one(image_file,tf_grapth)
      with open(image_file+'.ai', 'wb') as f:
          pickle.dump(emb[0,:], f)
      with open(image_file+'.id', 'wb') as f:
          pickle.dump(file_serializer.data['regid'], f)

      embs[file_serializer.data['regid'] ] = emb[0,:]  # add to cache

      return Response(file_serializer.data, status=status.HTTP_201_CREATED)
    else:
      return Response(file_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class RecView(APIView):
  parser_classes = (MultiPartParser, FormParser)
  def post(self, request, *args, **kwargs):
    file_serializer = RecSerializer(data=request.data)
    if file_serializer.is_valid():
      file_serializer.save()
      print(file_serializer.data['file'])
      image_file = "." + file_serializer.data['file']
      emb = facenet_distance.get_emb_one(image_file, tf_grapth)
      #print(emb)
      small_key=""
      old_dist=1000
      for key in embs:
          user_emb = embs[key]
          dist = np.sqrt(np.sum(np.square(np.subtract(emb[0, :], user_emb))))
          print("key===" + key + "=====%1.4f"%dist)
          if dist < old_dist :
              small_key=key
              old_dist=dist
      #byte_data = pickle.dumps(emb)
      #print (byte_data)ss
      #print(emb[0,:])
      #faceid=
      #dist = np.sqrt(np.sum(np.square(np.subtract(emb[0, :], emb2[0, :]))))
      print(small_key)
      print(old_dist)

      small_info=""
      small_data="成功匹配"
      if old_dist>0.8000 :
          small_data="=="+"可能是图片质量不好，系统没有找到这个人，但是找到一个跟你很像的人"
      if old_dist > 0.820:
          small_key =   "0"
          small_data="==可能是图片质量不好，系统没有找到这个人"
      small_percent=fn_percent(old_dist)

      small={'Name':small_key,'Percent':small_percent,'Info':small_data}

      return Response(small, status=status.HTTP_201_CREATED)
    else:
      return Response(file_serializer.errors, status=status.HTTP_400_BAD_REQUE)

class ListView(APIView):
  parser_classes = (MultiPartParser, FormParser)
  def post(self, request, *args, **kwargs):
    file_serializer = ListSerializer(data=request.data)
    if file_serializer.is_valid():
      ##file_serializer.save()
      print(file_serializer.data['listid'])

      return Response(emb, status=status.HTTP_201_CREATED)
    else:
      return Response(file_serializer.errors, status=status.HTTP_400_BAD_REQUE)


def django_image_and_file_upload_ajax(request):
    print("============")
    if request.method == 'POST':
       print("---------")
       form = ImageFileUploadForm(request.POST, request.FILES)
       print(request.FILES)
       if form.is_valid():

           form.save()
           return JsonResponse({'error': False, 'message': 'Uploaded Successfully'})
       else:
           print(form.errors)
           return JsonResponse({'error': True, 'errors': form.errors})
    else:
        form = ImageFileUploadForm()
        return render(request, 'django_image_upload_ajax.html', {'form': form})