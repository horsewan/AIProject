# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig
from .fd import facenet_distance

class AiConfig(AppConfig):
    name = 'ai'
    #ai_graph = facenet_distance.init_tf()